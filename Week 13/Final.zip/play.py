class Player:
    def __init__(self, name):
        '''This initializes the Player object with empty values'''
        self.wins = 0
        self.card = None
        self.name = name